import React from 'react';
import Main from './components/Main.jsx';
import './components/style.css';


const App=()=>{
    return(
        <>
            <Main/>
        </>
    )
}

export default App;